"use strict";

class Contact{
    constructor(name, city, email) {
        this.name = name;
        this.city = city;
        this.email = email;
    }
}

const contactList = [];

const contactInfoVar = document.getElementById("contact-info");
const contactAddBtn = document.getElementById("contact-add-btn");

const gridElement = document.getElementById("contact-grid");

const errorText = document.getElementById("error");

contactAddBtn.addEventListener('click', () => {
    const inputParams = contactInfoVar.value.split(",");
    if(inputParams.length !== 3){
        errorText.innerText = "Wrong amount of parameters -> Name, City, Email";
        errorText.style.visibility = "visible";
        console.log("Incorrect Parameter count");
        return;
    }

    if(!inputParams[0].trim()) {
        errorText.innerText = "No name provided";
        errorText.style.visibility = "visible";
        return;
    }else if(!inputParams[1].trim()){
        errorText.innerText = "No city provided";
        errorText.style.visibility = "visible";
        return;
    }else if(!inputParams[2].trim()){
        errorText.innerText = "No email provided";
        errorText.style.visibility = "visible";
        return;
    }

    if (!inputParams[2].trim().toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) {
        errorText.innerText = "Invalid email format";
        errorText.style.visibility = "visible";
        return;
    }

    contactInfoVar.value = "";

    contactList.push(new Contact(inputParams[0].trim(), inputParams[1].trim(), inputParams[2].trim()));

    printContacts();
});

function printContacts(){
    gridElement.innerHTML = '';

    for(let contact of contactList){
        let newElement = document.createElement("div");

        newElement.innerHTML = `<p><b>Name:</b> ${contact.name}</p>
                            <p><b>City:</b> ${contact.city}</p>
                            <p><b>Email:</b> ${contact.email}</p>`;

        newElement.classList.add("output");

        errorText.style.visibility = "hidden";

        gridElement.appendChild(newElement);

        gridElement.insertBefore(newElement, gridElement.firstChild);
    }
}